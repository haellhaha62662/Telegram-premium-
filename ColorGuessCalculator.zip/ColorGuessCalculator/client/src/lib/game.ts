export interface Prediction {
  periodNumber: string;
  result: "BIG" | "SMALL";
  timestamp: number;
}

const PATTERN = ["BIG", "BIG", "SMALL", "SMALL", "SMALL"] as const;

export function getPrediction(predictions: Prediction[]): "BIG" | "SMALL" {
  const position = predictions.length % PATTERN.length;
  return PATTERN[position] as "BIG" | "SMALL";
}

export function validatePeriodNumber(number: string): boolean {
  // Check if it's a valid period number format (17 digits)
  return /^\d{17}$/.test(number);
}