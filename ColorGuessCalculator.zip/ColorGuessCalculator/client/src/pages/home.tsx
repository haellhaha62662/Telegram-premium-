import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="min-h-screen bg-[#001a12] p-4 flex flex-col items-center justify-center space-y-8">
      <h1 className="text-3xl font-bold text-center text-white mb-8">
        SHAHMEER HACK SERVER
      </h1>

      {/* Game Type Buttons */}
      <div className="w-full max-w-md space-y-4">
        <Link href="/game">
          <Button 
            className="w-full py-6 text-xl font-semibold bg-gradient-to-r from-yellow-400 to-blue-500 hover:opacity-90"
          >
            BIG/SMALL
          </Button>
        </Link>

        <Link href="/game">
          <Button 
            className="w-full py-6 text-xl font-semibold bg-gradient-to-r from-red-500 to-green-500 hover:opacity-90"
          >
            RED/GREEN
          </Button>
        </Link>
      </div>

      {/* Info Card */}
      <div className="w-full max-w-md p-6 rounded-lg bg-[#0a2f25] text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="w-16 h-16 bg-red-600 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <span className="text-2xl font-bold text-white">Pak</span>
              <span className="block text-sm text-white">Game</span>
            </div>
          </div>
          <div className="text-lg">
            hack ONLY WORK IN<br />
            NEW ACCOUNT SO<br />
            REGISTER NOW
          </div>
        </div>
        <Link href="/game">
          <button className="w-full py-3 bg-[#00ffa3] text-black rounded-lg text-lg font-semibold hover:opacity-90">
            Start Playing
          </button>
        </Link>
      </div>
    </div>
  );
}