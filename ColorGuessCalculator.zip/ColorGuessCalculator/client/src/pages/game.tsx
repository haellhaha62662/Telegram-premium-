import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getPrediction, validatePeriodNumber, type Prediction } from "@/lib/game";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { AlertCircle, Info } from "lucide-react";

export default function Game() {
  const [periodNumber, setPeriodNumber] = useState("");
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [error, setError] = useState("");

  const handlePredict = () => {
    if (!validatePeriodNumber(periodNumber)) {
      setError("Period number must be 17 digits");
      return;
    }

    setError("");
    const newPrediction: Prediction = {
      periodNumber,
      result: getPrediction(predictions),
      timestamp: Date.now(),
    };

    setPredictions([...predictions, newPrediction]);
    setPeriodNumber("");
  };

  return (
    <div className="min-h-screen bg-[#001a12] p-4 space-y-6">
      {/* WhatsApp Contact Section */}
      <Card className="max-w-md mx-auto bg-[#25D366] text-white">
        <CardContent className="pt-6">
          <a 
            href="https://chat.whatsapp.com/Hgcv0eAUWY0AQU2qG8Z7Jw" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 text-lg font-medium hover:opacity-90"
          >
            <span className="text-2xl">💬</span>
            Contact for hacks
          </a>
        </CardContent>
      </Card>

      <Card className="max-w-md mx-auto bg-[#0a2f25] text-white">
        <CardHeader>
          <CardTitle className="text-center text-2xl font-bold">
            Color Prediction
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Input
              placeholder="Enter Period Number"
              value={periodNumber}
              onChange={(e) => setPeriodNumber(e.target.value)}
              className="text-center text-lg bg-[#001a12] border-[#00ffa3]"
              maxLength={17}
            />
            {error && (
              <div className="flex items-center gap-2 text-red-500 text-sm">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            )}
          </div>

          <Button 
            size="lg" 
            onClick={handlePredict}
            disabled={!periodNumber}
            className="w-full text-lg py-6 bg-[#00ffa3] text-black hover:opacity-90"
          >
            Predict
          </Button>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-center">Prediction History</h3>
            <div className="space-y-2">
              {predictions.map((pred, index) => (
                <motion.div
                  key={pred.timestamp}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn(
                    "p-4 rounded-lg text-white font-medium text-center",
                    pred.result === "BIG" ? "bg-blue-500" : "bg-red-500"
                  )}
                >
                  <div className="text-sm opacity-80">Period: {pred.periodNumber}</div>
                  <div className="text-xl font-bold">{pred.result}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Important Rules Section */}
      <Card className="max-w-md mx-auto bg-[#0a2f25] text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl text-[#00ffa3]">
            <Info className="w-5 h-5" />
            Important Rules
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-2">
              <span className="font-bold text-[#00ffa3]">1.</span>
              <p>Period number must be exactly 17 digits long.</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-bold text-[#00ffa3]">2.</span>
              <p>Each prediction is final and cannot be changed.</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-bold text-[#00ffa3]">3.</span>
              <p>Results are shown as either BIG (blue) or SMALL (red).</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-bold text-[#00ffa3]">4.</span>
              <p>You can view your prediction history below the prediction button.</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-bold text-[#00ffa3]">5.</span>
              <p>Make sure to double-check your period number before predicting.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
