import { motion } from "framer-motion";

interface ScoreDisplayProps {
  score: number;
}

export default function ScoreDisplay({ score }: ScoreDisplayProps) {
  return (
    <div className="flex justify-center">
      <motion.div
        key={score}
        initial={{ scale: 1.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="text-2xl font-bold text-primary"
      >
        Score: {score}
      </motion.div>
    </div>
  );
}
