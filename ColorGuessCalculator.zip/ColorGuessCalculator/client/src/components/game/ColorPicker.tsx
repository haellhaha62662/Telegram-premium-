import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface ColorPickerProps {
  colors: string[];
  selectedColor: string | null;
  onSelect: (color: string) => void;
  disabled?: boolean;
}

export default function ColorPicker({
  colors,
  selectedColor,
  onSelect,
  disabled
}: ColorPickerProps) {
  return (
    <div className="grid grid-cols-3 gap-4 md:gap-6">
      {colors.map((color, index) => (
        <motion.button
          key={color}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: index * 0.1 }}
          onClick={() => onSelect(color)}
          disabled={disabled}
          className={cn(
            "w-full aspect-square rounded-lg transition-transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
            selectedColor === color && "ring-4 ring-primary ring-offset-2",
            disabled && "opacity-50 cursor-not-allowed"
          )}
          style={{ backgroundColor: color }}
        />
      ))}
    </div>
  );
}
