import { motion } from "framer-motion";
import { CheckCircle, XCircle } from "lucide-react";

interface ResultDisplayProps {
  result: "correct" | "incorrect";
  selectedColor: string;
  winningColor: string;
}

export default function ResultDisplay({
  result,
  selectedColor,
  winningColor
}: ResultDisplayProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <div className="flex items-center justify-center gap-2">
        {result === "correct" ? (
          <CheckCircle className="w-6 h-6 text-green-500" />
        ) : (
          <XCircle className="w-6 h-6 text-red-500" />
        )}
        <span className="text-lg font-medium">
          {result === "correct" ? "Correct!" : "Wrong guess!"}
        </span>
      </div>

      <div className="flex justify-center gap-4">
        <div className="text-center">
          <div className="text-sm text-muted-foreground mb-2">Your Pick</div>
          <div
            className="w-16 h-16 rounded-lg"
            style={{ backgroundColor: selectedColor }}
          />
        </div>
        <div className="text-center">
          <div className="text-sm text-muted-foreground mb-2">Winning Color</div>
          <div
            className="w-16 h-16 rounded-lg"
            style={{ backgroundColor: winningColor }}
          />
        </div>
      </div>
    </motion.div>
  );
}
